package com.example.portfolio;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find views
        TextView aboutMeDetails = findViewById(R.id.aboutMeDetails);
        TextView educationDetails = findViewById(R.id.educationDetailsContent);
        TextView workExperienceDetails = findViewById(R.id.workExperienceDetailsContent);
        ImageView avatar = findViewById(R.id.avatar);

        // Set About Me details
        aboutMeDetails.setText("I am a passionate and dedicated Android developer with a strong interest in mobile application development. I have a Bachelor's degree in Computer Science and several years of experience in building Android apps. My skills include Java, Kotlin, Android SDK, and Firebase.");

        // Set Education details
        educationDetails.setText("Bachelor of Science in Computer Science\nUniversity: ABC University\nGraduation Year: 2020\nGPA: 3.8");

        // Set Work Experience details
        workExperienceDetails.setText("Android Developer\nCompany: XYZ Tech Inc.\nDuration: 2018 - Present\nResponsibilities: Developed and maintained Android applications, collaborated with cross-functional teams to define, design, and ship new features.");
    }
}
